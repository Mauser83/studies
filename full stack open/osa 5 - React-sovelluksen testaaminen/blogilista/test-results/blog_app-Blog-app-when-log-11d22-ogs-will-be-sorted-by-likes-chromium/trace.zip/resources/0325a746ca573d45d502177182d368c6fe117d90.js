import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=50ce589d"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/Blog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_propTypes from "/node_modules/.vite/deps/prop-types.js?v=50ce589d"; const PropTypes = __vite__cjsImport3_propTypes.__esModule ? __vite__cjsImport3_propTypes.default : __vite__cjsImport3_propTypes;
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=50ce589d"; const useState = __vite__cjsImport4_react["useState"];
const Blog = ({
  blog,
  like,
  user,
  delet
}) => {
  _s();
  const [expanded, setExpanded] = useState(false);
  const hideWhenVisible = {
    display: expanded ? "none" : ""
  };
  const showWhenVisible = {
    display: expanded ? "" : "none"
  };
  Blog.propTypes = {
    blog: PropTypes.object,
    user: PropTypes.object,
    like: PropTypes.func,
    delet: PropTypes.func
  };
  const blogStyle = {
    paddingTop: 10,
    paddingLeft: 2,
    border: "solid",
    borderWidth: 1,
    marginBottom: 5
  };
  const buttonStyle = {
    backgroundColor: "blue",
    color: "white",
    borderRadius: "10px"
  };
  const addLike = () => {
    like(blog);
  };
  const handleDelete = () => {
    delet(blog);
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "blog", style: blogStyle, children: [
    /* @__PURE__ */ jsxDEV(Fragment, { children: [
      blog.title,
      " ",
      blog.author
    ] }, void 0, true, {
      fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/Blog.jsx",
      lineNumber: 43,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: () => setExpanded(!expanded), children: expanded ? "hide" : "show" }, void 0, false, {
      fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/Blog.jsx",
      lineNumber: 46,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: showWhenVisible, className: "expandedContent", children: [
      blog.url,
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/Blog.jsx",
        lineNumber: 51,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Fragment, { children: [
        "likes ",
        blog.likes
      ] }, void 0, true, {
        fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/Blog.jsx",
        lineNumber: 52,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: addLike, children: "like" }, void 0, false, {
        fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/Blog.jsx",
        lineNumber: 53,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/Blog.jsx",
        lineNumber: 54,
        columnNumber: 9
      }, this),
      blog.user && blog.user.name ? blog.user.name : null,
      blog.user && user && blog.user.username === user.username ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
          fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/Blog.jsx",
          lineNumber: 57,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("button", { style: buttonStyle, onClick: handleDelete, children: "delete" }, void 0, false, {
          fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/Blog.jsx",
          lineNumber: 58,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/Blog.jsx",
        lineNumber: 56,
        columnNumber: 70
      }, this) : null
    ] }, void 0, true, {
      fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/Blog.jsx",
      lineNumber: 49,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/Blog.jsx",
    lineNumber: 42,
    columnNumber: 10
  }, this);
};
_s(Blog, "DuL5jiiQQFgbn7gBKAyxwS/H4Ek=");
_c = Blog;
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUNNOzs7Ozs7Ozs7Ozs7Ozs7OztBQXJDTixPQUFPQSxlQUFlO0FBQ3RCLFNBQVNDLGdCQUFnQjtBQUV6QixNQUFNQyxPQUFPQSxDQUFDO0FBQUEsRUFBRUM7QUFBQUEsRUFBTUM7QUFBQUEsRUFBTUM7QUFBQUEsRUFBTUM7QUFBTSxNQUFNO0FBQUFDLEtBQUE7QUFDNUMsUUFBTSxDQUFDQyxVQUFVQyxXQUFXLElBQUlSLFNBQVMsS0FBSztBQUM5QyxRQUFNUyxrQkFBa0I7QUFBQSxJQUFFQyxTQUFTSCxXQUFXLFNBQVM7QUFBQSxFQUFHO0FBQzFELFFBQU1JLGtCQUFrQjtBQUFBLElBQUVELFNBQVNILFdBQVcsS0FBSztBQUFBLEVBQU87QUFFMUROLE9BQUtXLFlBQVk7QUFBQSxJQUNmVixNQUFNSCxVQUFVYztBQUFBQSxJQUNoQlQsTUFBTUwsVUFBVWM7QUFBQUEsSUFDaEJWLE1BQU1KLFVBQVVlO0FBQUFBLElBQ2hCVCxPQUFPTixVQUFVZTtBQUFBQSxFQUNuQjtBQUNBLFFBQU1DLFlBQVk7QUFBQSxJQUNoQkMsWUFBWTtBQUFBLElBQ1pDLGFBQWE7QUFBQSxJQUNiQyxRQUFRO0FBQUEsSUFDUkMsYUFBYTtBQUFBLElBQ2JDLGNBQWM7QUFBQSxFQUNoQjtBQUNBLFFBQU1DLGNBQWM7QUFBQSxJQUNsQkMsaUJBQWlCO0FBQUEsSUFDakJDLE9BQU87QUFBQSxJQUNQQyxjQUFjO0FBQUEsRUFDaEI7QUFFQSxRQUFNQyxVQUFVQSxNQUFNO0FBQ3BCdEIsU0FBS0QsSUFBSTtBQUFBLEVBQ1g7QUFFQSxRQUFNd0IsZUFBZUEsTUFBTTtBQUN6QnJCLFVBQU1ILElBQUk7QUFBQSxFQUNaO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsUUFBTyxPQUFPYSxXQUMzQjtBQUFBLHVDQUNHYjtBQUFBQSxXQUFLeUI7QUFBQUEsTUFBTTtBQUFBLE1BQUV6QixLQUFLMEI7QUFBQUEsU0FEckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxZQUFPLFNBQVMsTUFBTXBCLFlBQVksQ0FBQ0QsUUFBUSxHQUN6Q0EscUJBQVcsU0FBUyxVQUR2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLFNBQUksT0FBT0ksaUJBQWlCLFdBQVUsbUJBQ3BDVDtBQUFBQSxXQUFLMkI7QUFBQUEsTUFDTix1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBRztBQUFBLE1BQ0gsbUNBQUU7QUFBQTtBQUFBLFFBQU8zQixLQUFLNEI7QUFBQUEsV0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9CO0FBQUEsTUFDcEIsdUJBQUMsWUFBTyxTQUFTTCxTQUFTLG9CQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQThCO0FBQUEsTUFDOUIsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUc7QUFBQSxNQUNGdkIsS0FBS0UsUUFBUUYsS0FBS0UsS0FBSzJCLE9BQU83QixLQUFLRSxLQUFLMkIsT0FBTztBQUFBLE1BQy9DN0IsS0FBS0UsUUFBUUEsUUFBUUYsS0FBS0UsS0FBSzRCLGFBQWE1QixLQUFLNEIsV0FDaEQsbUNBQ0U7QUFBQSwrQkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBRztBQUFBLFFBQ0gsdUJBQUMsWUFBTyxPQUFPWCxhQUFhLFNBQVNLLGNBQWEsc0JBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFdBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBLElBQ0U7QUFBQSxTQWROO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FlQTtBQUFBLE9BdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1QkE7QUFFSjtBQUFFcEIsR0ExRElMLE1BQUk7QUFBQWdDLEtBQUpoQztBQTRETixlQUFlQTtBQUFLLElBQUFnQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUHJvcFR5cGVzIiwidXNlU3RhdGUiLCJCbG9nIiwiYmxvZyIsImxpa2UiLCJ1c2VyIiwiZGVsZXQiLCJfcyIsImV4cGFuZGVkIiwic2V0RXhwYW5kZWQiLCJoaWRlV2hlblZpc2libGUiLCJkaXNwbGF5Iiwic2hvd1doZW5WaXNpYmxlIiwicHJvcFR5cGVzIiwib2JqZWN0IiwiZnVuYyIsImJsb2dTdHlsZSIsInBhZGRpbmdUb3AiLCJwYWRkaW5nTGVmdCIsImJvcmRlciIsImJvcmRlcldpZHRoIiwibWFyZ2luQm90dG9tIiwiYnV0dG9uU3R5bGUiLCJiYWNrZ3JvdW5kQ29sb3IiLCJjb2xvciIsImJvcmRlclJhZGl1cyIsImFkZExpa2UiLCJoYW5kbGVEZWxldGUiLCJ0aXRsZSIsImF1dGhvciIsInVybCIsImxpa2VzIiwibmFtZSIsInVzZXJuYW1lIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJCbG9nLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUHJvcFR5cGVzIGZyb20gXCJwcm9wLXR5cGVzXCI7XG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuXG5jb25zdCBCbG9nID0gKHsgYmxvZywgbGlrZSwgdXNlciwgZGVsZXQgfSkgPT4ge1xuICBjb25zdCBbZXhwYW5kZWQsIHNldEV4cGFuZGVkXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgaGlkZVdoZW5WaXNpYmxlID0geyBkaXNwbGF5OiBleHBhbmRlZCA/IFwibm9uZVwiIDogXCJcIiB9O1xuICBjb25zdCBzaG93V2hlblZpc2libGUgPSB7IGRpc3BsYXk6IGV4cGFuZGVkID8gXCJcIiA6IFwibm9uZVwiIH07XG5cbiAgQmxvZy5wcm9wVHlwZXMgPSB7XG4gICAgYmxvZzogUHJvcFR5cGVzLm9iamVjdCxcbiAgICB1c2VyOiBQcm9wVHlwZXMub2JqZWN0LFxuICAgIGxpa2U6IFByb3BUeXBlcy5mdW5jLFxuICAgIGRlbGV0OiBQcm9wVHlwZXMuZnVuYyxcbiAgfTtcbiAgY29uc3QgYmxvZ1N0eWxlID0ge1xuICAgIHBhZGRpbmdUb3A6IDEwLFxuICAgIHBhZGRpbmdMZWZ0OiAyLFxuICAgIGJvcmRlcjogXCJzb2xpZFwiLFxuICAgIGJvcmRlcldpZHRoOiAxLFxuICAgIG1hcmdpbkJvdHRvbTogNSxcbiAgfTtcbiAgY29uc3QgYnV0dG9uU3R5bGUgPSB7XG4gICAgYmFja2dyb3VuZENvbG9yOiBcImJsdWVcIixcbiAgICBjb2xvcjogXCJ3aGl0ZVwiLFxuICAgIGJvcmRlclJhZGl1czogXCIxMHB4XCIsXG4gIH07XG5cbiAgY29uc3QgYWRkTGlrZSA9ICgpID0+IHtcbiAgICBsaWtlKGJsb2cpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZURlbGV0ZSA9ICgpID0+IHtcbiAgICBkZWxldChibG9nKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmxvZ1wiIHN0eWxlPXtibG9nU3R5bGV9PlxuICAgICAgPD5cbiAgICAgICAge2Jsb2cudGl0bGV9IHtibG9nLmF1dGhvcn1cbiAgICAgIDwvPlxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRFeHBhbmRlZCghZXhwYW5kZWQpfT5cbiAgICAgICAge2V4cGFuZGVkID8gXCJoaWRlXCIgOiBcInNob3dcIn1cbiAgICAgIDwvYnV0dG9uPlxuICAgICAgPGRpdiBzdHlsZT17c2hvd1doZW5WaXNpYmxlfSBjbGFzc05hbWU9XCJleHBhbmRlZENvbnRlbnRcIj5cbiAgICAgICAge2Jsb2cudXJsfVxuICAgICAgICA8YnIgLz5cbiAgICAgICAgPD5saWtlcyB7YmxvZy5saWtlc308Lz5cbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXthZGRMaWtlfT5saWtlPC9idXR0b24+XG4gICAgICAgIDxiciAvPlxuICAgICAgICB7YmxvZy51c2VyICYmIGJsb2cudXNlci5uYW1lID8gYmxvZy51c2VyLm5hbWUgOiBudWxsfVxuICAgICAgICB7YmxvZy51c2VyICYmIHVzZXIgJiYgYmxvZy51c2VyLnVzZXJuYW1lID09PSB1c2VyLnVzZXJuYW1lID8gKFxuICAgICAgICAgIDw+XG4gICAgICAgICAgICA8YnIgLz5cbiAgICAgICAgICAgIDxidXR0b24gc3R5bGU9e2J1dHRvblN0eWxlfSBvbkNsaWNrPXtoYW5kbGVEZWxldGV9PlxuICAgICAgICAgICAgICBkZWxldGVcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvPlxuICAgICAgICApIDogbnVsbH1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgQmxvZztcbiJdLCJmaWxlIjoiQzovVXNlcnMvc2luaXIvT25lRHJpdmUvRGVza3RvcC9mdWxsIHN0YWNrIG9wZW4vb3NhIDUvYmxvZ2lsaXN0YS9mcm9udGVuZC9zcmMvY29tcG9uZW50cy9CbG9nLmpzeCJ9