import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=50ce589d"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=50ce589d"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import Blog from "/src/components/Blog.jsx";
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/login.js";
import LoginForm from "/src/components/LoginForm.jsx";
import Togglable from "/src/components/Togglable.jsx";
import CreateBlog from "/src/components/CreateBlog.jsx";
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  const [notificationMessage, setNotificationMessage] = useState(null);
  const addBlogFormRef = useRef();
  useEffect(() => {
    blogService.getAll().then((blogs2) => {
      const sortedBlogs = blogs2.sort((a, b) => b.likes - a.likes);
      setBlogs(sortedBlogs);
    });
  }, []);
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("loggedBlogappUser");
    if (loggedUserJSON) {
      const user2 = JSON.parse(loggedUserJSON);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  const handleLogin = async (event) => {
    event.preventDefault();
    try {
      const user2 = await loginService.login({
        username,
        password
      });
      window.localStorage.setItem("loggedBlogappUser", JSON.stringify(user2));
      blogService.setToken(user2.token);
      setUser(user2);
      setUsername("");
      setPassword("");
    } catch (exception) {
      setNotificationMessage({
        text: "wrong username or password",
        color: "red"
      });
      setTimeout(() => {
        setNotificationMessage(null);
      }, 5e3);
    }
  };
  const handleLogout = () => {
    window.localStorage.removeItem("loggedBlogappUser");
    blogService.setToken(null);
    setUser(null);
  };
  const handleLike = (blog) => {
    const updatedBlog = {
      ...blog,
      likes: blog.likes + 1
    };
    blogService.update(blog.id, updatedBlog).then((update) => {
      const updatedBlogs = blogs.map((b) => b.id !== update.id ? b : update);
      const sortedBlogs = updatedBlogs.sort((a, b) => b.likes - a.likes);
      setBlogs(sortedBlogs);
    });
  };
  const handleDelete = (blog) => {
    if (window.confirm(`Remove blog ${blog.title} by ${blog.author}`)) {
      blogService.remove(blog.id).then(() => {
        const blogsLeft = blogs.filter((b) => b.id !== blog.id);
        setBlogs(blogsLeft);
      });
    }
  };
  const addBlog = (blogObject) => {
    blogService.create(blogObject).then((blog) => {
      setBlogs(blogs.concat(blog));
      setNotificationMessage({
        text: `a new blog ${blog.title} by ${blog.author} added`,
        color: "green"
      });
      addBlogFormRef.current.toggleVisibility();
      setTimeout(() => {
        setNotificationMessage(null);
      }, 5e3);
    });
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h1", { children: "Blogs" }, void 0, false, {
      fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/App.jsx",
      lineNumber: 91,
      columnNumber: 7
    }, this),
    notificationMessage && /* @__PURE__ */ jsxDEV("div", { style: {
      color: notificationMessage.color
    }, className: "Notification", children: notificationMessage.text }, void 0, false, {
      fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/App.jsx",
      lineNumber: 92,
      columnNumber: 31
    }, this),
    !user && /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "log in", children: /* @__PURE__ */ jsxDEV(LoginForm, { username, password, handleUsernameChange: ({
      target
    }) => setUsername(target.value), handlePasswordChange: ({
      target
    }) => setPassword(target.value), handleSubmit: handleLogin }, void 0, false, {
      fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/App.jsx",
      lineNumber: 99,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/App.jsx",
      lineNumber: 98,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/App.jsx",
      lineNumber: 97,
      columnNumber: 17
    }, this),
    user && /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV(Fragment, { children: [
        user.name,
        " logged in"
      ] }, void 0, true, {
        fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/App.jsx",
        lineNumber: 107,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("button", { onClick: handleLogout, children: "Logout" }, void 0, false, {
        fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/App.jsx",
        lineNumber: 108,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "create blog", ref: addBlogFormRef, children: /* @__PURE__ */ jsxDEV(CreateBlog, { createBlog: addBlog }, void 0, false, {
        fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/App.jsx",
        lineNumber: 110,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/App.jsx",
        lineNumber: 109,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/App.jsx",
      lineNumber: 106,
      columnNumber: 16
    }, this),
    blogs.map((blog) => /* @__PURE__ */ jsxDEV(Blog, { blog, like: handleLike, user, delet: handleDelete }, blog.id, false, {
      fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/App.jsx",
      lineNumber: 114,
      columnNumber: 26
    }, this))
  ] }, void 0, true, {
    fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/App.jsx",
    lineNumber: 90,
    columnNumber: 10
  }, this);
};
_s(App, "Xpjm+9FGDVUGL8UOKiEUxX5ZCNw=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0dNLFNBd0JJLFVBeEJKOzs7Ozs7Ozs7Ozs7Ozs7OztBQWhHTixTQUFTQSxVQUFVQyxXQUFXQyxjQUFjO0FBQzVDLE9BQU9DLFVBQVU7QUFDakIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MsZ0JBQWdCO0FBRXZCLE1BQU1DLE1BQU1BLE1BQU07QUFBQUMsS0FBQTtBQUNoQixRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSVosU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ2EsVUFBVUMsV0FBVyxJQUFJZCxTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDZSxVQUFVQyxXQUFXLElBQUloQixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDaUIsTUFBTUMsT0FBTyxJQUFJbEIsU0FBUyxJQUFJO0FBQ3JDLFFBQU0sQ0FBQ21CLHFCQUFxQkMsc0JBQXNCLElBQUlwQixTQUFTLElBQUk7QUFDbkUsUUFBTXFCLGlCQUFpQm5CLE9BQU87QUFFOUJELFlBQVUsTUFBTTtBQUNkRyxnQkFBWWtCLE9BQU8sRUFBRUMsS0FBTVosWUFBVTtBQUNuQyxZQUFNYSxjQUFjYixPQUFNYyxLQUFLLENBQUNDLEdBQUdDLE1BQU1BLEVBQUVDLFFBQVFGLEVBQUVFLEtBQUs7QUFDMURoQixlQUFTWSxXQUFXO0FBQUEsSUFDdEIsQ0FBQztBQUFBLEVBQ0gsR0FBRyxFQUFFO0FBRUx2QixZQUFVLE1BQU07QUFDZCxVQUFNNEIsaUJBQWlCQyxPQUFPQyxhQUFhQyxRQUFRLG1CQUFtQjtBQUN0RSxRQUFJSCxnQkFBZ0I7QUFDbEIsWUFBTVosUUFBT2dCLEtBQUtDLE1BQU1MLGNBQWM7QUFDdENYLGNBQVFELEtBQUk7QUFDWmIsa0JBQVkrQixTQUFTbEIsTUFBS21CLEtBQUs7QUFBQSxJQUNqQztBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwsUUFBTUMsY0FBYyxPQUFPQyxVQUFVO0FBQ25DQSxVQUFNQyxlQUFlO0FBQ3JCLFFBQUk7QUFDRixZQUFNdEIsUUFBTyxNQUFNWixhQUFhbUMsTUFBTTtBQUFBLFFBQ3BDM0I7QUFBQUEsUUFDQUU7QUFBQUEsTUFDRixDQUFDO0FBRURlLGFBQU9DLGFBQWFVLFFBQVEscUJBQXFCUixLQUFLUyxVQUFVekIsS0FBSSxDQUFDO0FBQ3JFYixrQkFBWStCLFNBQVNsQixNQUFLbUIsS0FBSztBQUMvQmxCLGNBQVFELEtBQUk7QUFDWkgsa0JBQVksRUFBRTtBQUNkRSxrQkFBWSxFQUFFO0FBQUEsSUFDaEIsU0FBUzJCLFdBQVc7QUFDbEJ2Qiw2QkFBdUI7QUFBQSxRQUNyQndCLE1BQU07QUFBQSxRQUNOQyxPQUFPO0FBQUEsTUFDVCxDQUFDO0FBQ0RDLGlCQUFXLE1BQU07QUFDZjFCLCtCQUF1QixJQUFJO0FBQUEsTUFDN0IsR0FBRyxHQUFJO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFFQSxRQUFNMkIsZUFBZUEsTUFBTTtBQUN6QmpCLFdBQU9DLGFBQWFpQixXQUFXLG1CQUFtQjtBQUNsRDVDLGdCQUFZK0IsU0FBUyxJQUFJO0FBQ3pCakIsWUFBUSxJQUFJO0FBQUEsRUFDZDtBQUVBLFFBQU0rQixhQUFjQyxVQUFTO0FBQzNCLFVBQU1DLGNBQWM7QUFBQSxNQUFFLEdBQUdEO0FBQUFBLE1BQU10QixPQUFPc0IsS0FBS3RCLFFBQVE7QUFBQSxJQUFFO0FBQ3JEeEIsZ0JBQVlnRCxPQUFPRixLQUFLRyxJQUFJRixXQUFXLEVBQUU1QixLQUFNNkIsWUFBVztBQUN4RCxZQUFNRSxlQUFnQjNDLE1BQU00QyxJQUFLNUIsT0FBT0EsRUFBRTBCLE9BQU9ELE9BQU9DLEtBQUsxQixJQUFJeUIsTUFBTztBQUN4RSxZQUFNNUIsY0FBYzhCLGFBQWE3QixLQUFLLENBQUNDLEdBQUdDLE1BQU1BLEVBQUVDLFFBQVFGLEVBQUVFLEtBQUs7QUFDakVoQixlQUFTWSxXQUFXO0FBQUEsSUFDdEIsQ0FBQztBQUFBLEVBQ0g7QUFFQSxRQUFNZ0MsZUFBZ0JOLFVBQVM7QUFDN0IsUUFBSXBCLE9BQU8yQixRQUFTLGVBQWNQLEtBQUtRLEtBQU0sT0FBTVIsS0FBS1MsTUFBTyxFQUFDLEdBQUc7QUFDakV2RCxrQkFBWXdELE9BQU9WLEtBQUtHLEVBQUUsRUFBRTlCLEtBQUssTUFBTTtBQUNyQyxjQUFNc0MsWUFBWWxELE1BQU1tRCxPQUFRbkMsT0FBTUEsRUFBRTBCLE9BQU9ILEtBQUtHLEVBQUU7QUFDdER6QyxpQkFBU2lELFNBQVM7QUFBQSxNQUNwQixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFFQSxRQUFNRSxVQUFXQyxnQkFBZTtBQUM5QjVELGdCQUFZNkQsT0FBT0QsVUFBVSxFQUFFekMsS0FBTTJCLFVBQVM7QUFDNUN0QyxlQUFTRCxNQUFNdUQsT0FBT2hCLElBQUksQ0FBQztBQUMzQjlCLDZCQUF1QjtBQUFBLFFBQ3JCd0IsTUFBTyxjQUFhTSxLQUFLUSxLQUFNLE9BQU1SLEtBQUtTLE1BQU87QUFBQSxRQUNqRGQsT0FBTztBQUFBLE1BQ1QsQ0FBQztBQUNEeEIscUJBQWU4QyxRQUFRQyxpQkFBaUI7QUFDeEN0QixpQkFBVyxNQUFNO0FBQ2YxQiwrQkFBdUIsSUFBSTtBQUFBLE1BQzdCLEdBQUcsR0FBSTtBQUFBLElBQ1QsQ0FBQztBQUFBLEVBQ0g7QUFFQSxTQUNFLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxRQUFHLHFCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUztBQUFBLElBQ1JELHVCQUNDLHVCQUFDLFNBQ0MsT0FBTztBQUFBLE1BQUUwQixPQUFPMUIsb0JBQW9CMEI7QUFBQUEsSUFBTSxHQUMxQyxXQUFVLGdCQUVUMUIsOEJBQW9CeUIsUUFKdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsSUFFRCxDQUFDM0IsUUFDQSx1QkFBQyxTQUNDLGlDQUFDLGFBQVUsYUFBWSxVQUNyQixpQ0FBQyxhQUNDLFVBQ0EsVUFDQSxzQkFBc0IsQ0FBQztBQUFBLE1BQUVvRDtBQUFBQSxJQUFPLE1BQU12RCxZQUFZdUQsT0FBT0MsS0FBSyxHQUM5RCxzQkFBc0IsQ0FBQztBQUFBLE1BQUVEO0FBQUFBLElBQU8sTUFBTXJELFlBQVlxRCxPQUFPQyxLQUFLLEdBQzlELGNBQWNqQyxlQUxoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSzRCLEtBTjlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBRURwQixRQUNDLHVCQUFDLFNBQ0M7QUFBQSx5Q0FBR0E7QUFBQUEsYUFBS3NEO0FBQUFBLFFBQUs7QUFBQSxXQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUI7QUFBQSxNQUN2Qix1QkFBQyxZQUFPLFNBQVN4QixjQUFjLHNCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFDO0FBQUEsTUFDckMsdUJBQUMsYUFBVSxhQUFZLGVBQWMsS0FBSzFCLGdCQUN4QyxpQ0FBQyxjQUFXLFlBQVkwQyxXQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdDLEtBRGxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsSUFHRHBELE1BQU00QyxJQUFLTCxVQUNWLHVCQUFDLFFBRUMsTUFDQSxNQUFNRCxZQUNOLE1BQ0EsT0FBT08sZ0JBSkZOLEtBQUtHLElBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtzQixDQUV2QjtBQUFBLE9BekNIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwQ0E7QUFFSjtBQUFDM0MsR0FuSUtELEtBQUc7QUFBQStELEtBQUgvRDtBQXFJTixlQUFlQTtBQUFHLElBQUErRDtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJCbG9nIiwiYmxvZ1NlcnZpY2UiLCJsb2dpblNlcnZpY2UiLCJMb2dpbkZvcm0iLCJUb2dnbGFibGUiLCJDcmVhdGVCbG9nIiwiQXBwIiwiX3MiLCJibG9ncyIsInNldEJsb2dzIiwidXNlcm5hbWUiLCJzZXRVc2VybmFtZSIsInBhc3N3b3JkIiwic2V0UGFzc3dvcmQiLCJ1c2VyIiwic2V0VXNlciIsIm5vdGlmaWNhdGlvbk1lc3NhZ2UiLCJzZXROb3RpZmljYXRpb25NZXNzYWdlIiwiYWRkQmxvZ0Zvcm1SZWYiLCJnZXRBbGwiLCJ0aGVuIiwic29ydGVkQmxvZ3MiLCJzb3J0IiwiYSIsImIiLCJsaWtlcyIsImxvZ2dlZFVzZXJKU09OIiwid2luZG93IiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsIkpTT04iLCJwYXJzZSIsInNldFRva2VuIiwidG9rZW4iLCJoYW5kbGVMb2dpbiIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJsb2dpbiIsInNldEl0ZW0iLCJzdHJpbmdpZnkiLCJleGNlcHRpb24iLCJ0ZXh0IiwiY29sb3IiLCJzZXRUaW1lb3V0IiwiaGFuZGxlTG9nb3V0IiwicmVtb3ZlSXRlbSIsImhhbmRsZUxpa2UiLCJibG9nIiwidXBkYXRlZEJsb2ciLCJ1cGRhdGUiLCJpZCIsInVwZGF0ZWRCbG9ncyIsIm1hcCIsImhhbmRsZURlbGV0ZSIsImNvbmZpcm0iLCJ0aXRsZSIsImF1dGhvciIsInJlbW92ZSIsImJsb2dzTGVmdCIsImZpbHRlciIsImFkZEJsb2ciLCJibG9nT2JqZWN0IiwiY3JlYXRlIiwiY29uY2F0IiwiY3VycmVudCIsInRvZ2dsZVZpc2liaWxpdHkiLCJ0YXJnZXQiLCJ2YWx1ZSIsIm5hbWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgQmxvZyBmcm9tICcuL2NvbXBvbmVudHMvQmxvZydcbmltcG9ydCBibG9nU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2Jsb2dzJ1xuaW1wb3J0IGxvZ2luU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2xvZ2luJ1xuaW1wb3J0IExvZ2luRm9ybSBmcm9tICcuL2NvbXBvbmVudHMvTG9naW5Gb3JtJ1xuaW1wb3J0IFRvZ2dsYWJsZSBmcm9tICcuL2NvbXBvbmVudHMvVG9nZ2xhYmxlJ1xuaW1wb3J0IENyZWF0ZUJsb2cgZnJvbSAnLi9jb21wb25lbnRzL0NyZWF0ZUJsb2cnXG5cbmNvbnN0IEFwcCA9ICgpID0+IHtcbiAgY29uc3QgW2Jsb2dzLCBzZXRCbG9nc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW3VzZXJuYW1lLCBzZXRVc2VybmFtZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW25vdGlmaWNhdGlvbk1lc3NhZ2UsIHNldE5vdGlmaWNhdGlvbk1lc3NhZ2VdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgYWRkQmxvZ0Zvcm1SZWYgPSB1c2VSZWYoKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgYmxvZ1NlcnZpY2UuZ2V0QWxsKCkudGhlbigoYmxvZ3MpID0+IHtcbiAgICAgIGNvbnN0IHNvcnRlZEJsb2dzID0gYmxvZ3Muc29ydCgoYSwgYikgPT4gYi5saWtlcyAtIGEubGlrZXMpXG4gICAgICBzZXRCbG9ncyhzb3J0ZWRCbG9ncylcbiAgICB9KVxuICB9LCBbXSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGxvZ2dlZFVzZXJKU09OID0gd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKCdsb2dnZWRCbG9nYXBwVXNlcicpXG4gICAgaWYgKGxvZ2dlZFVzZXJKU09OKSB7XG4gICAgICBjb25zdCB1c2VyID0gSlNPTi5wYXJzZShsb2dnZWRVc2VySlNPTilcbiAgICAgIHNldFVzZXIodXNlcilcbiAgICAgIGJsb2dTZXJ2aWNlLnNldFRva2VuKHVzZXIudG9rZW4pXG4gICAgfVxuICB9LCBbXSlcblxuICBjb25zdCBoYW5kbGVMb2dpbiA9IGFzeW5jIChldmVudCkgPT4ge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcbiAgICB0cnkge1xuICAgICAgY29uc3QgdXNlciA9IGF3YWl0IGxvZ2luU2VydmljZS5sb2dpbih7XG4gICAgICAgIHVzZXJuYW1lLFxuICAgICAgICBwYXNzd29yZCxcbiAgICAgIH0pXG5cbiAgICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnbG9nZ2VkQmxvZ2FwcFVzZXInLCBKU09OLnN0cmluZ2lmeSh1c2VyKSlcbiAgICAgIGJsb2dTZXJ2aWNlLnNldFRva2VuKHVzZXIudG9rZW4pXG4gICAgICBzZXRVc2VyKHVzZXIpXG4gICAgICBzZXRVc2VybmFtZSgnJylcbiAgICAgIHNldFBhc3N3b3JkKCcnKVxuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgc2V0Tm90aWZpY2F0aW9uTWVzc2FnZSh7XG4gICAgICAgIHRleHQ6ICd3cm9uZyB1c2VybmFtZSBvciBwYXNzd29yZCcsXG4gICAgICAgIGNvbG9yOiAncmVkJyxcbiAgICAgIH0pXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgc2V0Tm90aWZpY2F0aW9uTWVzc2FnZShudWxsKVxuICAgICAgfSwgNTAwMClcbiAgICB9XG4gIH1cblxuICBjb25zdCBoYW5kbGVMb2dvdXQgPSAoKSA9PiB7XG4gICAgd2luZG93LmxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdsb2dnZWRCbG9nYXBwVXNlcicpXG4gICAgYmxvZ1NlcnZpY2Uuc2V0VG9rZW4obnVsbClcbiAgICBzZXRVc2VyKG51bGwpXG4gIH1cblxuICBjb25zdCBoYW5kbGVMaWtlID0gKGJsb2cpID0+IHtcbiAgICBjb25zdCB1cGRhdGVkQmxvZyA9IHsgLi4uYmxvZywgbGlrZXM6IGJsb2cubGlrZXMgKyAxIH1cbiAgICBibG9nU2VydmljZS51cGRhdGUoYmxvZy5pZCwgdXBkYXRlZEJsb2cpLnRoZW4oKHVwZGF0ZSkgPT4ge1xuICAgICAgY29uc3QgdXBkYXRlZEJsb2dzID0gKGJsb2dzLm1hcCgoYikgPT4gKGIuaWQgIT09IHVwZGF0ZS5pZCA/IGIgOiB1cGRhdGUpKSlcbiAgICAgIGNvbnN0IHNvcnRlZEJsb2dzID0gdXBkYXRlZEJsb2dzLnNvcnQoKGEsIGIpID0+IGIubGlrZXMgLSBhLmxpa2VzKVxuICAgICAgc2V0QmxvZ3Moc29ydGVkQmxvZ3MpXG4gICAgfSlcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZURlbGV0ZSA9IChibG9nKSA9PiB7XG4gICAgaWYgKHdpbmRvdy5jb25maXJtKGBSZW1vdmUgYmxvZyAke2Jsb2cudGl0bGV9IGJ5ICR7YmxvZy5hdXRob3J9YCkpIHtcbiAgICAgIGJsb2dTZXJ2aWNlLnJlbW92ZShibG9nLmlkKS50aGVuKCgpID0+IHtcbiAgICAgICAgY29uc3QgYmxvZ3NMZWZ0ID0gYmxvZ3MuZmlsdGVyKChiKSA9PiBiLmlkICE9PSBibG9nLmlkKVxuICAgICAgICBzZXRCbG9ncyhibG9nc0xlZnQpXG4gICAgICB9KVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGFkZEJsb2cgPSAoYmxvZ09iamVjdCkgPT4ge1xuICAgIGJsb2dTZXJ2aWNlLmNyZWF0ZShibG9nT2JqZWN0KS50aGVuKChibG9nKSA9PiB7XG4gICAgICBzZXRCbG9ncyhibG9ncy5jb25jYXQoYmxvZykpXG4gICAgICBzZXROb3RpZmljYXRpb25NZXNzYWdlKHtcbiAgICAgICAgdGV4dDogYGEgbmV3IGJsb2cgJHtibG9nLnRpdGxlfSBieSAke2Jsb2cuYXV0aG9yfSBhZGRlZGAsXG4gICAgICAgIGNvbG9yOiAnZ3JlZW4nLFxuICAgICAgfSlcbiAgICAgIGFkZEJsb2dGb3JtUmVmLmN1cnJlbnQudG9nZ2xlVmlzaWJpbGl0eSgpXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgc2V0Tm90aWZpY2F0aW9uTWVzc2FnZShudWxsKVxuICAgICAgfSwgNTAwMClcbiAgICB9KVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGgxPkJsb2dzPC9oMT5cbiAgICAgIHtub3RpZmljYXRpb25NZXNzYWdlICYmIChcbiAgICAgICAgPGRpdlxuICAgICAgICAgIHN0eWxlPXt7IGNvbG9yOiBub3RpZmljYXRpb25NZXNzYWdlLmNvbG9yIH19XG4gICAgICAgICAgY2xhc3NOYW1lPVwiTm90aWZpY2F0aW9uXCJcbiAgICAgICAgPlxuICAgICAgICAgIHtub3RpZmljYXRpb25NZXNzYWdlLnRleHR9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICAgIHshdXNlciAmJiAoXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPFRvZ2dsYWJsZSBidXR0b25MYWJlbD1cImxvZyBpblwiPlxuICAgICAgICAgICAgPExvZ2luRm9ybVxuICAgICAgICAgICAgICB1c2VybmFtZT17dXNlcm5hbWV9XG4gICAgICAgICAgICAgIHBhc3N3b3JkPXtwYXNzd29yZH1cbiAgICAgICAgICAgICAgaGFuZGxlVXNlcm5hbWVDaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRVc2VybmFtZSh0YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBoYW5kbGVQYXNzd29yZENoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFBhc3N3b3JkKHRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGhhbmRsZVN1Ym1pdD17aGFuZGxlTG9naW59XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvVG9nZ2xhYmxlPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgICB7dXNlciAmJiAoXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPD57dXNlci5uYW1lfSBsb2dnZWQgaW48Lz5cbiAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e2hhbmRsZUxvZ291dH0+TG9nb3V0PC9idXR0b24+XG4gICAgICAgICAgPFRvZ2dsYWJsZSBidXR0b25MYWJlbD1cImNyZWF0ZSBibG9nXCIgcmVmPXthZGRCbG9nRm9ybVJlZn0+XG4gICAgICAgICAgICA8Q3JlYXRlQmxvZyBjcmVhdGVCbG9nPXthZGRCbG9nfSAvPlxuICAgICAgICAgIDwvVG9nZ2xhYmxlPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHtibG9ncy5tYXAoKGJsb2cpID0+IChcbiAgICAgICAgPEJsb2dcbiAgICAgICAgICBrZXk9e2Jsb2cuaWR9XG4gICAgICAgICAgYmxvZz17YmxvZ31cbiAgICAgICAgICBsaWtlPXtoYW5kbGVMaWtlfVxuICAgICAgICAgIHVzZXI9e3VzZXJ9XG4gICAgICAgICAgZGVsZXQ9e2hhbmRsZURlbGV0ZX1cbiAgICAgICAgLz5cbiAgICAgICkpfVxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcFxuIl0sImZpbGUiOiJDOi9Vc2Vycy9zaW5pci9PbmVEcml2ZS9EZXNrdG9wL2Z1bGwgc3RhY2sgb3Blbi9vc2EgNS9ibG9naWxpc3RhL2Zyb250ZW5kL3NyYy9BcHAuanN4In0=