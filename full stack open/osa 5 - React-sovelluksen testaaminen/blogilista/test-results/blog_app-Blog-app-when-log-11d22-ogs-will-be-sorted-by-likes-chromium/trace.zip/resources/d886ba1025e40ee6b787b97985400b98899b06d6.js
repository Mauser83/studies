import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CreateBlog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=50ce589d"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/CreateBlog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_propTypes from "/node_modules/.vite/deps/prop-types.js?v=50ce589d"; const PropTypes = __vite__cjsImport3_propTypes.__esModule ? __vite__cjsImport3_propTypes.default : __vite__cjsImport3_propTypes;
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=50ce589d"; const useState = __vite__cjsImport4_react["useState"];
const CreateBlog = ({
  createBlog
}) => {
  _s();
  const [newBlog, setNewBlog] = useState({
    title: "",
    author: "",
    url: ""
  });
  CreateBlog.propTypes = {
    createBlog: PropTypes.func
  };
  const handleChange = (event) => {
    const {
      name,
      value
    } = event.target;
    setNewBlog({
      ...newBlog,
      [name]: value
    });
  };
  const addBlog = (event) => {
    event.preventDefault();
    createBlog(newBlog);
    setNewBlog({
      title: "",
      author: "",
      url: ""
    });
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Create new" }, void 0, false, {
      fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/CreateBlog.jsx",
      lineNumber: 36,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: addBlog, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        "Title",
        " ",
        /* @__PURE__ */ jsxDEV("input", { type: "text", "data-testid": "title", value: newBlog.title, name: "title", onChange: handleChange, placeholder: "write title here" }, void 0, false, {
          fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/CreateBlog.jsx",
          lineNumber: 40,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/CreateBlog.jsx",
        lineNumber: 38,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "Author",
        " ",
        /* @__PURE__ */ jsxDEV("input", { type: "text", "data-testid": "author", value: newBlog.author, name: "author", onChange: handleChange, placeholder: "write author here" }, void 0, false, {
          fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/CreateBlog.jsx",
          lineNumber: 44,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/CreateBlog.jsx",
        lineNumber: 42,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "URL",
        " ",
        /* @__PURE__ */ jsxDEV("input", { type: "text", "data-testid": "url", value: newBlog.url, name: "url", onChange: handleChange, placeholder: "write url here" }, void 0, false, {
          fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/CreateBlog.jsx",
          lineNumber: 48,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/CreateBlog.jsx",
        lineNumber: 46,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "Save" }, void 0, false, {
        fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/CreateBlog.jsx",
        lineNumber: 50,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/CreateBlog.jsx",
      lineNumber: 37,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/CreateBlog.jsx",
    lineNumber: 35,
    columnNumber: 10
  }, this);
};
_s(CreateBlog, "pUgMQJReK1PHQLbaQFe5FKtVyzI=");
_c = CreateBlog;
export default CreateBlog;
var _c;
$RefreshReg$(_c, "CreateBlog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/CreateBlog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0JJLG1CQUNFLGNBREY7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBL0JKLE9BQU9BLGVBQWU7QUFDdEIsU0FBU0MsZ0JBQWdCO0FBRXpCLE1BQU1DLGFBQWFBLENBQUM7QUFBQSxFQUFFQztBQUFXLE1BQU07QUFBQUMsS0FBQTtBQUNyQyxRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSUwsU0FBUztBQUFBLElBQ3JDTSxPQUFPO0FBQUEsSUFDUEMsUUFBUTtBQUFBLElBQ1JDLEtBQUs7QUFBQSxFQUNQLENBQUM7QUFFRFAsYUFBV1EsWUFBWTtBQUFBLElBQ3JCUCxZQUFZSCxVQUFVVztBQUFBQSxFQUN4QjtBQUVBLFFBQU1DLGVBQWdCQyxXQUFVO0FBQzlCLFVBQU07QUFBQSxNQUFFQztBQUFBQSxNQUFNQztBQUFBQSxJQUFNLElBQUlGLE1BQU1HO0FBQzlCVixlQUFXO0FBQUEsTUFBRSxHQUFHRDtBQUFBQSxNQUFTLENBQUNTLElBQUksR0FBR0M7QUFBQUEsSUFBTSxDQUFDO0FBQUEsRUFDMUM7QUFFQSxRQUFNRSxVQUFXSixXQUFVO0FBQ3pCQSxVQUFNSyxlQUFlO0FBQ3JCZixlQUFXRSxPQUFPO0FBRWxCQyxlQUFXO0FBQUEsTUFDVEMsT0FBTztBQUFBLE1BQ1BDLFFBQVE7QUFBQSxNQUNSQyxLQUFLO0FBQUEsSUFDUCxDQUFDO0FBQUEsRUFDSDtBQUVBLFNBQ0UsbUNBQ0U7QUFBQSwyQkFBQyxRQUFHLDBCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYztBQUFBLElBQ2QsdUJBQUMsVUFBSyxVQUFVUSxTQUNkO0FBQUEsNkJBQUMsU0FBRztBQUFBO0FBQUEsUUFDSTtBQUFBLFFBQ04sdUJBQUMsV0FDQyxNQUFLLFFBQ0wsZUFBWSxTQUNaLE9BQU9aLFFBQVFFLE9BQ2YsTUFBSyxTQUNMLFVBQVVLLGNBQ1YsYUFBWSxzQkFOZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTWdDO0FBQUEsV0FSbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFDQSx1QkFBQyxTQUFHO0FBQUE7QUFBQSxRQUNLO0FBQUEsUUFDUCx1QkFBQyxXQUNDLE1BQUssUUFDTCxlQUFZLFVBQ1osT0FBT1AsUUFBUUcsUUFDZixNQUFLLFVBQ0wsVUFBVUksY0FDVixhQUFZLHVCQU5kO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNaUM7QUFBQSxXQVJuQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUNBLHVCQUFDLFNBQUc7QUFBQTtBQUFBLFFBQ0U7QUFBQSxRQUNKLHVCQUFDLFdBQ0MsTUFBSyxRQUNMLGVBQVksT0FDWixPQUFPUCxRQUFRSSxLQUNmLE1BQUssT0FDTCxVQUFVRyxjQUNWLGFBQVksb0JBTmQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU04QjtBQUFBLFdBUmhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLE1BQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsb0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBMEI7QUFBQSxTQWxDNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1DQTtBQUFBLE9BckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzQ0E7QUFFSjtBQUFDUixHQXBFS0YsWUFBVTtBQUFBaUIsS0FBVmpCO0FBc0VOLGVBQWVBO0FBQVUsSUFBQWlCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJQcm9wVHlwZXMiLCJ1c2VTdGF0ZSIsIkNyZWF0ZUJsb2ciLCJjcmVhdGVCbG9nIiwiX3MiLCJuZXdCbG9nIiwic2V0TmV3QmxvZyIsInRpdGxlIiwiYXV0aG9yIiwidXJsIiwicHJvcFR5cGVzIiwiZnVuYyIsImhhbmRsZUNoYW5nZSIsImV2ZW50IiwibmFtZSIsInZhbHVlIiwidGFyZ2V0IiwiYWRkQmxvZyIsInByZXZlbnREZWZhdWx0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDcmVhdGVCbG9nLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnXG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuXG5jb25zdCBDcmVhdGVCbG9nID0gKHsgY3JlYXRlQmxvZyB9KSA9PiB7XG4gIGNvbnN0IFtuZXdCbG9nLCBzZXROZXdCbG9nXSA9IHVzZVN0YXRlKHtcbiAgICB0aXRsZTogJycsXG4gICAgYXV0aG9yOiAnJyxcbiAgICB1cmw6ICcnLFxuICB9KVxuXG4gIENyZWF0ZUJsb2cucHJvcFR5cGVzID0ge1xuICAgIGNyZWF0ZUJsb2c6IFByb3BUeXBlcy5mdW5jXG4gIH1cblxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZXZlbnQpID0+IHtcbiAgICBjb25zdCB7IG5hbWUsIHZhbHVlIH0gPSBldmVudC50YXJnZXRcbiAgICBzZXROZXdCbG9nKHsgLi4ubmV3QmxvZywgW25hbWVdOiB2YWx1ZSB9KVxuICB9XG5cbiAgY29uc3QgYWRkQmxvZyA9IChldmVudCkgPT4ge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcbiAgICBjcmVhdGVCbG9nKG5ld0Jsb2cpXG5cbiAgICBzZXROZXdCbG9nKHtcbiAgICAgIHRpdGxlOiAnJyxcbiAgICAgIGF1dGhvcjogJycsXG4gICAgICB1cmw6ICcnLFxuICAgIH0pXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8aDI+Q3JlYXRlIG5ldzwvaDI+XG4gICAgICA8Zm9ybSBvblN1Ym1pdD17YWRkQmxvZ30+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgVGl0bGV7JyAnfVxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgZGF0YS10ZXN0aWQ9J3RpdGxlJ1xuICAgICAgICAgICAgdmFsdWU9e25ld0Jsb2cudGl0bGV9XG4gICAgICAgICAgICBuYW1lPVwidGl0bGVcIlxuICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPSd3cml0ZSB0aXRsZSBoZXJlJ1xuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIEF1dGhvcnsnICd9XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICBkYXRhLXRlc3RpZD0nYXV0aG9yJ1xuICAgICAgICAgICAgdmFsdWU9e25ld0Jsb2cuYXV0aG9yfVxuICAgICAgICAgICAgbmFtZT1cImF1dGhvclwiXG4gICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9J3dyaXRlIGF1dGhvciBoZXJlJ1xuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIFVSTHsnICd9XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICBkYXRhLXRlc3RpZD0ndXJsJ1xuICAgICAgICAgICAgdmFsdWU9e25ld0Jsb2cudXJsfVxuICAgICAgICAgICAgbmFtZT1cInVybFwiXG4gICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9J3dyaXRlIHVybCBoZXJlJ1xuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIj5TYXZlPC9idXR0b24+XG4gICAgICA8L2Zvcm0+XG4gICAgPC8+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgQ3JlYXRlQmxvZ1xuIl0sImZpbGUiOiJDOi9Vc2Vycy9zaW5pci9PbmVEcml2ZS9EZXNrdG9wL2Z1bGwgc3RhY2sgb3Blbi9vc2EgNS9ibG9naWxpc3RhL2Zyb250ZW5kL3NyYy9jb21wb25lbnRzL0NyZWF0ZUJsb2cuanN4In0=