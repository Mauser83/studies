import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/LoginForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=50ce589d"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/LoginForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_propTypes from "/node_modules/.vite/deps/prop-types.js?v=50ce589d"; const PropTypes = __vite__cjsImport3_propTypes.__esModule ? __vite__cjsImport3_propTypes.default : __vite__cjsImport3_propTypes;
const LoginForm = ({
  handleSubmit,
  handleUsernameChange,
  handlePasswordChange,
  username,
  password
}) => {
  LoginForm.propTypes = {
    handleSubmit: PropTypes.func,
    handleUserNameChange: PropTypes.func,
    handlePassWordChange: PropTypes.func,
    username: PropTypes.string.isRequired,
    password: PropTypes.string.isRequired
  };
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Login" }, void 0, false, {
      fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/LoginForm.jsx",
      lineNumber: 17,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxDEV("div", { children: [
        "username",
        /* @__PURE__ */ jsxDEV("input", { type: "text", "data-testid": "username", value: username, name: "Username", onChange: handleUsernameChange }, void 0, false, {
          fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/LoginForm.jsx",
          lineNumber: 21,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/LoginForm.jsx",
        lineNumber: 19,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "password",
        /* @__PURE__ */ jsxDEV("input", { type: "password", "data-testid": "password", value: password, name: "Password", onChange: handlePasswordChange }, void 0, false, {
          fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/LoginForm.jsx",
          lineNumber: 25,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/LoginForm.jsx",
        lineNumber: 23,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "login" }, void 0, false, {
        fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/LoginForm.jsx",
        lineNumber: 27,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/LoginForm.jsx",
      lineNumber: 18,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/LoginForm.jsx",
    lineNumber: 16,
    columnNumber: 10
  }, this);
};
_c = LoginForm;
export default LoginForm;
var _c;
$RefreshReg$(_c, "LoginForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/sinir/OneDrive/Desktop/full stack open/osa 5/blogilista/frontend/src/components/LoginForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJJLG1CQUNFLGNBREY7QUFqQkosT0FBT0Esb0JBQWU7QUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFbEMsTUFBTUMsWUFBWUEsQ0FBQztBQUFBLEVBQ2pCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNGLE1BQU07QUFDSkwsWUFBVU0sWUFBWTtBQUFBLElBQ3BCTCxjQUFjRixVQUFVUTtBQUFBQSxJQUN4QkMsc0JBQXNCVCxVQUFVUTtBQUFBQSxJQUNoQ0Usc0JBQXNCVixVQUFVUTtBQUFBQSxJQUNoQ0gsVUFBVUwsVUFBVVcsT0FBT0M7QUFBQUEsSUFDM0JOLFVBQVVOLFVBQVVXLE9BQU9DO0FBQUFBLEVBQzdCO0FBQ0EsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLFFBQUcscUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFTO0FBQUEsSUFDVCx1QkFBQyxVQUFLLFVBQVVWLGNBQ2Q7QUFBQSw2QkFBQyxTQUFHO0FBQUE7QUFBQSxRQUVGLHVCQUFDLFdBQ0MsTUFBSyxRQUNMLGVBQVksWUFDWixPQUFPRyxVQUNQLE1BQUssWUFDTCxVQUFVRix3QkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS2lDO0FBQUEsV0FQbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFDQSx1QkFBQyxTQUFHO0FBQUE7QUFBQSxRQUVGLHVCQUFDLFdBQ0MsTUFBSyxZQUNMLGVBQVksWUFDWixPQUFPRyxVQUNQLE1BQUssWUFDTCxVQUFVRix3QkFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS2lDO0FBQUEsV0FQbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFDQSx1QkFBQyxZQUFPLE1BQUssVUFBUyxxQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyQjtBQUFBLFNBckI3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBc0JBO0FBQUEsT0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXlCQTtBQUVKO0FBQUNTLEtBMUNLWjtBQTRDTixlQUFlQTtBQUFTLElBQUFZO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJQcm9wVHlwZXMiLCJMb2dpbkZvcm0iLCJoYW5kbGVTdWJtaXQiLCJoYW5kbGVVc2VybmFtZUNoYW5nZSIsImhhbmRsZVBhc3N3b3JkQ2hhbmdlIiwidXNlcm5hbWUiLCJwYXNzd29yZCIsInByb3BUeXBlcyIsImZ1bmMiLCJoYW5kbGVVc2VyTmFtZUNoYW5nZSIsImhhbmRsZVBhc3NXb3JkQ2hhbmdlIiwic3RyaW5nIiwiaXNSZXF1aXJlZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTG9naW5Gb3JtLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnXG5cbmNvbnN0IExvZ2luRm9ybSA9ICh7XG4gIGhhbmRsZVN1Ym1pdCxcbiAgaGFuZGxlVXNlcm5hbWVDaGFuZ2UsXG4gIGhhbmRsZVBhc3N3b3JkQ2hhbmdlLFxuICB1c2VybmFtZSxcbiAgcGFzc3dvcmRcbn0pID0+IHtcbiAgTG9naW5Gb3JtLnByb3BUeXBlcyA9IHtcbiAgICBoYW5kbGVTdWJtaXQ6IFByb3BUeXBlcy5mdW5jLFxuICAgIGhhbmRsZVVzZXJOYW1lQ2hhbmdlOiBQcm9wVHlwZXMuZnVuYyxcbiAgICBoYW5kbGVQYXNzV29yZENoYW5nZTogUHJvcFR5cGVzLmZ1bmMsXG4gICAgdXNlcm5hbWU6IFByb3BUeXBlcy5zdHJpbmcuaXNSZXF1aXJlZCxcbiAgICBwYXNzd29yZDogUHJvcFR5cGVzLnN0cmluZy5pc1JlcXVpcmVkXG4gIH1cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPGgyPkxvZ2luPC9oMj5cbiAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIHVzZXJuYW1lXG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICBkYXRhLXRlc3RpZD0ndXNlcm5hbWUnXG4gICAgICAgICAgICB2YWx1ZT17dXNlcm5hbWV9XG4gICAgICAgICAgICBuYW1lPVwiVXNlcm5hbWVcIlxuICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZVVzZXJuYW1lQ2hhbmdlfVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIHBhc3N3b3JkXG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgZGF0YS10ZXN0aWQ9J3Bhc3N3b3JkJ1xuICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkfVxuICAgICAgICAgICAgbmFtZT1cIlBhc3N3b3JkXCJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVQYXNzd29yZENoYW5nZX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCI+bG9naW48L2J1dHRvbj5cbiAgICAgIDwvZm9ybT5cbiAgICA8Lz5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBMb2dpbkZvcm0iXSwiZmlsZSI6IkM6L1VzZXJzL3NpbmlyL09uZURyaXZlL0Rlc2t0b3AvZnVsbCBzdGFjayBvcGVuL29zYSA1L2Jsb2dpbGlzdGEvZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvTG9naW5Gb3JtLmpzeCJ9